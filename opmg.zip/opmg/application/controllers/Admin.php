<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	
	public function index()
	{
                 $this->load->helper('url');
                 $this->load->database();


                 $data["home_active"] = "";
                 $data["admin_active"] = "active";
                 $data["shipping_active"] = "";

                 $data['title'] = "OPG|Admin";
                 $this->load->view('\shared\head_view',$data);
                 $this->load->view('\shared\menu_view',$data);
                 $this->load->view('\admin\admin_view');

                 $this->load->view('\shared\footer_view');

               
    }
    

    public function item_type()
    {
        $this->load->helper('url');
       


        $data["home_active"] = "";
        $data["admin_active"] = "active";
        $data["shipping_active"] = "";

        $data['title'] = "OPG|Item Type";
        $this->load->view('\shared\head_view',$data);
        $this->load->view('\shared\menu_view',$data);
       

        $this->load->view('\shared\footer_view');   

    }
}
