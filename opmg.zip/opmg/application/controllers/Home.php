<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	
	public function index()
	{
                 $this->load->helper('url');
                 $this->load->database();


                 $data["home_active"] = "active";
                 $data["admin_active"] = "";
                 $data["shipping_active"] = "";

                 $data['title'] = "OPG|Store";
                 $data['item_type'] = $this->db->query('Select type_desc from item_type');

                 $this->load->view('\shared\head_view',$data);
                 $this->load->view('\shared\menu_view',$data);
                 
                 $this->load->view('\home\home_view',$data);
                 $this->load->view('\shared\footer_view');

               // $this->load->view('welcome_message');
	}
}
