<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shipping extends CI_Controller {

	
	public function index()
	{
                 $this->load->helper('url');

                 $data["home_active"] = "";
                 $data["admin_active"] = "";
                 $data["shipping_active"] = "active";
                 $data['title'] = "OPG|Shipping";

                 $this->load->view('\shared\head_view',$data);
                 $this->load->view('\shared\menu_view',$data);
                 $this->load->view('\shared\footer_view');

               // $this->load->view('welcome_message');
	}
}
