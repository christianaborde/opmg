<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div style="padding:5px;">
               <br> 
              BROWSE <br> <br>
              <?php foreach($item_type->result() as $t) { ?>
                  <a href="#">  <?php echo $t->type_desc; ?> </a><br>

              <?php } ?> 

              <br><br>
              EXTRA INFO
              <br>
              <br>
              <p>
              At OnePunchGame, you’ll find all the PC parts and accessories you need. With our huge selection of Computers Parts at reasonable prices, you’re guaranteed to walk away with a top-quality product that suits your needs. Order now and take advantage of our limited time offers.    
              </p>
        </div>

    </div>
    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">


    </div>



</div>


