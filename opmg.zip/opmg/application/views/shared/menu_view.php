<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body style="font-family:Exo 2, Arial, Helvetica, sans-serif;">
   <div class="container"> 
   
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#E21C2B;color:#ffffff;">
        <div style="text-align:center;">
        <img src="<?php echo base_url(); ?>assets/images/opg.jpg"  > <br><br>
        <h3>OPG Online Store</h3>

        </div>
        
        <button  class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse navbar-right" id="navbarNav" >
            <ul class="navbar-nav">
            <li class="nav-item <?php echo $home_active ?>">
               <a href="<?php echo site_url('home/index') ?>" class="nav-link">STORE<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item <?php echo $shipping_active ?>">
                <a class="nav-link" href="<?php echo site_url('shipping/index') ?>">SHIPPING</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">CONDITIONS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">CONTACT</a>
            </li>
            <li class="nav-item <?php echo $admin_active ?>">
                <a class="nav-link" href="<?php echo site_url('admin/index') ?>">ADMIN</a>
            </li>

            </ul>
        </div>
    </nav>

    

    
            

    