<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
    <script type='text/javascript' src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
    <script type='text/javascript' src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.css">
    

    <title><?= $title ?></title>
    

</head>



