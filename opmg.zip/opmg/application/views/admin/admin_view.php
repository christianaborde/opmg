<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="row">
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
        <br>
        <button style="cursor:pointer;" onclick="window.location='<?php echo site_url('admin/item_type') ?>'"> Item Type List</button>
    </div>

</div>

